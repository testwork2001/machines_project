
<?php $__env->startSection('title', " {$spec->name}التعديل على "); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">

        <div class="col-12">
            <?php echo $__env->make('admin.layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('admin.layouts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <form action="<?php echo e(route('specs.update',$spec->id)); ?>" method="post">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="col-xl-8 mb-30 mx-auto">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title">التعديل على بيانات <?php echo e($spec->name); ?></h5>
                        <div class="row mb-20">
                            <div class="col-md-4">
                                <label>اسم الصفه *</label>
                                <input type="text" class="form-control" placeholder="ادخل اسم الصفه" name='name' value="<?php echo e($spec->name); ?>">
                            </div>
                            <div class="col-md-2 pt-4">
                                <input type="submit" value="حفظ التعديل" class="btn btn-success my-1">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Projects\machines_project\resources\views/admin/specs/edit.blade.php ENDPATH**/ ?>