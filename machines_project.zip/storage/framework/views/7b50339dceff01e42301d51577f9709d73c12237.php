
<?php $__env->startSection('title', 'خدمتنا'); ?>
<?php $__env->startSection('content'); ?>
     <!-- Service Start -->
    <div class="service" dir="rtl">
        <div class="container bg-light rounded p-2">
            <div class="section-header text-center">
                <p>خدمتنا</p>
                <h2>ماذا نسطيع ان نقدم لعملائنا</h2>
            </div>
            <div class="row text-center justify-content-around">
                <div class="col-11 col-md-5 col-xl-3 mx-2 my-2 rounded bg-white">
                    <div class="service-item p-1">
                        <i class="flaticon-car-wash-1"></i>
                        <h3>الشركه العربيه لتجاره</h3>
                        <p> بالنقر على الزرّ، فإنك توافق على شروط الخدمة. سنعالج بياناتك الشخصية لتلبية طلبك ولأغراض أخرى
                            وفقًا لـ سياسة الخصوصية. ويمكنك إلغاء المدفوعات المتكررة في أي وقت.</p>
                    </div>
                </div>
                <div class="col-11 col-md-5 col-xl-3 mx-2 my-2 rounded bg-white">
                    <div class="service-item p-1">
                        <i class="flaticon-car-wash"></i>
                        <h3>الشركه العربيه لتجاره</h3>
                        <p> بالنقر على الزرّ، فإنك توافق على شروط الخدمة. سنعالج بياناتك الشخصية لتلبية طلبك ولأغراض أخرى
                            وفقًا لـ سياسة الخصوصية. ويمكنك إلغاء المدفوعات المتكررة في أي وقت.</p>
                    </div>
                </div>
                <div class="col-11 col-md-5 col-xl-3 mx-2 my-2 rounded bg-white">
                    <div class="service-item p-1">
                        <i class="flaticon-vacuum-cleaner"></i>
                        <h3>الشركه العربيه لتجاره</h3>
                        <p> بالنقر على الزرّ، فإنك توافق على شروط الخدمة. سنعالج بياناتك الشخصية لتلبية طلبك ولأغراض أخرى
                            وفقًا لـ سياسة الخصوصية. ويمكنك إلغاء المدفوعات المتكررة في أي وقت.</p>
                    </div>
                </div>
                <div class="col-11 col-md-5 col-xl-3 mx-2 my-2 rounded bg-white">
                    <div class="service-item p-1">
                        <i class="flaticon-seat"></i>
                        <h3>الشركه العربيه لتجاره</h3>
                        <p> بالنقر على الزرّ، فإنك توافق على شروط الخدمة. سنعالج بياناتك الشخصية لتلبية طلبك ولأغراض أخرى
                            وفقًا لـ سياسة الخصوصية. ويمكنك إلغاء المدفوعات المتكررة في أي وقت.</p>
                    </div>
                </div>
                <div class="col-11 col-md-5 col-xl-3 mx-2 my-2 rounded bg-white">
                    <div class="service-item p-1">
                        <i class="flaticon-car-service"></i>
                        <h3>الشركه العربيه لتجاره</h3>
                        <p> بالنقر على الزرّ، فإنك توافق على شروط الخدمة. سنعالج بياناتك الشخصية لتلبية طلبك ولأغراض أخرى
                            وفقًا لـ سياسة الخصوصية. ويمكنك إلغاء المدفوعات المتكررة في أي وقت.</p>
                    </div>
                </div>
                <div class="col-11 col-md-5 col-xl-3 mx-2 my-2 rounded bg-white">
                    <div class="service-item p-1">
                        <i class="flaticon-car-service-2"></i>
                        <h3>الشركه العربيه لتجاره</h3>
                        <p> بالنقر على الزرّ، فإنك توافق على شروط الخدمة. سنعالج بياناتك الشخصية لتلبية طلبك ولأغراض أخرى
                            وفقًا لـ سياسة الخصوصية. ويمكنك إلغاء المدفوعات المتكررة في أي وقت.</p>
                    </div>
                </div>
                <div class="col-11 col-md-5 col-xl-3 mx-2 my-2 rounded bg-white">
                    <div class="service-item p-1">
                        <i class="flaticon-car-wash"></i>
                        <h3>الشركه العربيه لتجاره</h3>
                        <p> بالنقر على الزرّ، فإنك توافق على شروط الخدمة. سنعالج بياناتك الشخصية لتلبية طلبك ولأغراض أخرى
                            وفقًا لـ سياسة الخصوصية. ويمكنك إلغاء المدفوعات المتكررة في أي وقت.</p>
                    </div>
                </div>
                <div class="col-11 col-md-5 col-xl-3 mx-2 my-2 rounded bg-white">
                    <div class="service-item p-1">
                        <i class="flaticon-brush-1"></i>
                        <h3>الشركه العربيه لتجاره</h3>
                        <p> بالنقر على الزرّ، فإنك توافق على شروط الخدمة. سنعالج بياناتك الشخصية لتلبية طلبك ولأغراض أخرى
                            وفقًا لـ سياسة الخصوصية. ويمكنك إلغاء المدفوعات المتكررة في أي وقت.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Service End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Projects\machines_project\resources\views/web/services.blade.php ENDPATH**/ ?>