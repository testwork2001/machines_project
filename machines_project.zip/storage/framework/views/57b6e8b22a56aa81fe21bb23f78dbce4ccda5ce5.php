
<?php $__env->startSection('title', ' المنتجات'); ?>
<?php $__env->startSection('content'); ?>
    <div class="blog" dir="rtl">
        <div class="col-11 col-md-8 col-lg-6 mx-auto mb-2 row justify-content-center">
            <input type="search" id="search" class="col-sm-8 form-control p-2 fs-2" placeholder="بحث عن منتج..."
                style="height:50px" required>
            <button type="button" class="btn btn-danger col-sm-3 mx-1 my-2 my-sm-0" id="btn-search">بحث</button>
        </div>
        <div class="container">
            <div class="section-header text-center my-3">
                <p>منتجاتنا</p>
                <h2>كل المنتجات</h2>
            </div>

            <div class="row products">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 product-item">
                        <div class="blog-item">
                            <div class="blog-img">
                                <a href="<?php echo e(route('details' , ['slug'=>$product->slug])); ?>"><img src="<?php echo e(asset($product->getFirstMediaUrl('products'))); ?>" alt="Image"></a>
                                <div class="show_detials">
                                    <p><a href="<?php echo e(route('details' , ['slug'=>$product->slug])); ?>" class="btn btn-danger "> عرض المزيد</a></p>
                                </div>
                            </div>
                            <div class="blog-text text-right">
                                <h3><a href="<?php echo e(route('details', $product->slug)); ?>"><?php echo e($product->name); ?></a></h3>
                                <p class="mt-0">
                                    <?php echo e($product->description); ?>

                                </p>
                            </div>
                            <div class="blog-meta">
                                <p class="text-right">
                                    <a >
                                        <i class="fas fa-money-bill-wave"></i>
                                        <span class=""><?php echo e($product->price . ' '); ?> جنيه </span>
                                    </a>
                                </p>
                                <p class="text-right">
                                    <a>
                                        <i class="fas fa-shopping-basket  "></i>
                                        <span class=""><?php echo e($product->quantity); ?>

                                            <?php echo e($product->quantity > 1 ? ' من الوحدات ' : ' وحده '); ?></span>
                                    </a>
                                </p>
                                <p class="text-right">
                                    <a >
                                        <i class="fa fa-comments  "></i>
                                        <span class=""><?php echo e($product->inquiries_count); ?></span>
                                    </a>
                                </p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $('#btn-search').on('click', function() {
            $.ajax({
                type: "get",
                url: "<?php echo e(asset('api/products/search/')); ?>",
                data: {
                    "key": $('#search').val()
                },
                headers: {
                    "accept": "application/json",
                    "accept-language": 'ar'
                },
                success: function(response, status) {
                    $('.products').empty()
                    $('.products').html(response.htmlData)

                },
                error: function(xhr, status, error) {

                }
            });
        })

        
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Projects\machines_project\resources\views/web/products.blade.php ENDPATH**/ ?>