

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <?php echo $__env->make('admin.layouts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="page-title">
            <div class="row">
                <div class="col-12">
                    <h4 class="mb-2">كل المنتجات الموجوده حاليا</h4>
                    <div class="co-12 p-2 text-center">
                        <a href="<?php echo e(route('products.create')); ?>" class="btn btn-success">انشاء منتج</a>
                    </div>
                </div>

            </div>
        </div>
        <!-- main body -->
        <div class="row">
            <div class="col-xl-12 mb-30">
                <div class="card card-statistics h-100">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="datatable" class="table center-aligned-table mb-0 p-0">
                                <thead>
                                    <tr>
                                        <th>رقم المنتج</th>
                                        <th>صوره المنتج</th>
                                        <th>اسم المنتج</th>
                                        <th>اسم القسم التابع له</th>
                                        <th>السعر</th>
                                        <th>الكميه</th>
                                        <th>الحاله</th>
                                        <th>تاريخ الانشاء</th>
                                        <th>تاريخ التعديل</th>
                                        <th>العمليات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <th><?php echo e($loop->iteration); ?></th>
                                            <th><img src="<?php echo e(asset($product->getFirstMediaUrl('products'))); ?>"
                                                    style="width:50px;height:50px;border-radius:50%"></th>
                                            <th><?php echo e($product->name); ?></th>
                                            <th><?php echo e($product->category->name); ?> </th>

                                            <th><?php echo e($product->price); ?> جنيه</th>
                                            <th class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                                'text-danger' => $product->quantity == 0,
                                                'text-warning' => $product->quantity > 0 && $product->quantity < 15,
                                                'text-success' => $product->quantity > 15,
                                            ]) ?>"><?php echo e($product->quantity); ?>

                                                <?php echo e($product->quantity > 1 ? ' من وحدات' : 'وحده'); ?></th>
                                            <td><label
                                                    class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                                        'badge fs-1',
                                                        'badge-danger' => $product->status == '0',
                                                        'badge-success' => $product->status == '1',
                                                    ]) ?>"><?php echo e($product->status == '1' ? 'متاح حاليا' : 'غير متاح حاليا'); ?></label>
                                            </td>
                                            <th><?php echo e($product->created_at); ?> </th>
                                            <th><?php echo e($product->updated_at); ?> </th>
                                            <th><a href="<?php echo e(route('products.edit', $product->id)); ?>"
                                                    class="btn btn-success m-1">
                                                    تعديل</a>
                                                <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="post"
                                                    class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <input type="submit" value="حذف" class="btn btn-outline-danger m-1">
                                                </form>
                                            </th>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>
                                </tbody>


                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Projects\machines_project\resources\views/admin/products/index.blade.php ENDPATH**/ ?>