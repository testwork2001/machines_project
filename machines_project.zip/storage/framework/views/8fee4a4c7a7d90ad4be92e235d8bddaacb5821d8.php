
<?php $__env->startSection('title', "Edit For {$product->name}"); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="col-12">
            <?php echo $__env->make('admin.layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('admin.layouts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <form action="<?php echo e(route('products.update', $product->id)); ?>" method="post" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="col-xl-8 mb-30 mx-auto">
                <div class="card card-statistics h-100">
                    <div class="card-body">
                        <h5 class="card-title">التعديل على بيانات هذا المنتج <?php echo e($product->name); ?></h5>
                        <div>
                            <h3>البيانات الاساسيه</h3>
                            <section class="my-2">
                                <h4 class="sr-only">&nbsp;</h4>
                                <p>
                                    <label for="title-3"> اسم المنتج * </label><br />
                                    <input id="title-3" type="text" class="form-control" name="name"
                                        value="<?php echo e($product->name); ?>"><br />
                                    <label for="title-3"> سعر المنتج *</label><br />
                                    <input id="title-3" type="text" class="form-control" name="price"
                                        value="<?php echo e($product->price); ?>"><br />
                                    <label for="title-3"> الكميه *</label><br />
                                    <input id="title-3" type="number" class="form-control" name="quantity"
                                        value="<?php echo e($product->quantity); ?>"><br />
                                    <label for="title-3"> القسم التابع له *</label><br />
                                    <select name="category_id" class="form-control" style="height: 50px">
                                        <option selected disabled></option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"
                                                <?php echo e($product->category_id == $category->id ? 'selected' : ''); ?>>
                                                <?php echo e($category->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select><br />
                                    <label for="title-3">حاله المنتج *</label><br />
                                    <select name="status" class="form-control" style="height: 50px">
                                        <option selected disbaled></option>
                                        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($status); ?>"
                                                <?php echo e($product->status == $status ? 'selected' : ''); ?>><?php echo e($key); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select><br />
                                    <label for="text-3">التفاصيل *</label><br />
                                    <textarea id="text-3" rows="10" class="form-control" name="description"> <?php echo e($product->description); ?></textarea>
                                </p>

                            </section>
                            <h3 class="pt-5">مواصفات المنتج</h3>
                            <section>
                                <div class="card-body">
                                    <div class="repeater-add">
                                        <div data-repeater-list="specs">
                                            <?php $__currentLoopData = $product->specs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productspec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div data-repeater-item>
                                                    <div class="row mb-20">
                                                        <div class="col-md-4 fs-3">
                                                            <label for="inputAddress">الصفه</label>
                                                            <select class="form-control" id="inputAddress" name='spec_id'
                                                                style="height:50px">
                                                                <?php $__currentLoopData = $specs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($spec->id); ?>"
                                                                        <?php echo e($productspec->pivot->spec_id == $spec->id ? 'selected' : ''); ?>>
                                                                        <?php echo e($spec->name); ?>

                                                                    </option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                            </select>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <label for="inputAddress5">القيمه</label>
                                                            <input type="text" class="form-control" id="inputAddress5"
                                                                placeholder="ادخل قيمه الصفه" name='value'
                                                                value="<?php echo e($productspec->pivot->value); ?>">
                                                        </div>
                                                        <div class="col-md-2">
                                                            <input class="btn btn-danger btn-block mt-30"
                                                                data-repeater-delete type="button" value="Delete" />
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <div class="form-group clearfix mb-20">
                                            <input class="button" data-repeater-create type="button" value="اضافه صفه " />
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <h3 class="p-2">الصور الحاليه لهذا المنتج</h3>
                            <section>
                                <div class="col-12 row p-2 justify-content-around">
                                    <?php $__currentLoopData = $product->getMedia('products'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-11 col-md-5 col-xl-3 text-center my-2">
                                            <img src="<?php echo e(asset($media->getUrl())); ?>" alt=""
                                                style="width: 250px;height:200px">
                                            <div class="form-group row text-center">
                    
                                                <input type="checkbox" name="oldimages[<?php echo e($index); ?>][id]"
                                                    id="media<?php echo e($index); ?>"class='w-100 p-5 my-2' value="<?php echo e($media->id); ?>" >
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </section>
                            <h3 class="pt-5">اختر صور جديده للمنتج</h3>
                            <section>
                                <div class="card-body">
                                    <div class="repeater-add">
                                        <div data-repeater-list="images">
                                            <div data-repeater-item>
                                                <div class="row mb-20">
                                                    <div class="form-group">
                                                        <label for="">اختر صوره</label>
                                                        <input type="file" name='file_name' class="form-control">
                                                    </div>
                                                    <div class="col-md-2">
                                                        <input class="btn btn-danger btn-block mt-30" data-repeater-delete
                                                            type="button" value="حذف" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group clearfix mb-20">
                                            <input class="button" data-repeater-create type="button"
                                                value="اضافه صوره " />
                                        </div>
                                    </div>
                            </section>
                            <div class="col-12 text-center p-3">
                                <input type="submit" value="حفظ التعديلات" class="btn btn-success my-1">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        function UpdatePreview() {
            $('#frame').attr('src', URL.createObjectURL(event.target.files[0]));
        };
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Projects\machines_project\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>