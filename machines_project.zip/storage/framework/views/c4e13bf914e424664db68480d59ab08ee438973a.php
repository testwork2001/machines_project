
<?php $__env->startSection('title', 'الصفخه الشخصيه'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper profile-page">
        <div class="row">
            <div class="col-lg-12 mb-30">
                <div class="card">
                    <div class="card-body">
                        <div class="user-bg" style="background: url(<?php echo e(asset('admin/images/user-bg.jpg')); ?>);">
                            <div class="user-info">
                                <div class="row">
                                    <div class="col-lg-6 align-self-center">
                                        <div class="user-dp px-2">
                                            <label for="image">
                                                <img src="<?php echo e(Auth::user()->getFirstMediaUrl('admins') ? asset(Auth::user()->getFirstMediaUrl('admins')) : asset('admin/images/admin_def.webp')); ?>"alt=""
                                                    id="frame" style="height: 120px;width:150px">
                                                <input type="file" name="image" class="d-none" id="image"
                                                    oninput='UpdatePreview()'form="admin-data">
                                            </label>
                                        </div>
                                        <div class="user-detail">
                                            <h2 class="name"><?php echo e($admin->name); ?></h2>
                                            <p class="designation mb-0"><?php echo e($admin->email); ?></p>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <?php echo $__env->make('admin.layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('admin.layouts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-xl-6 mb-30 mx-auto">
                <div class="card mb-30 about-me">
                    <div class="card-body">
                        <h5 class="card-title">معلوماتى</h5>
                        <form action="<?php echo e(route('profile.update', $admin->id)); ?>" method="post"
                            enctype="multipart/form-data" id="admin-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group my-2">
                                <label for="name" class="form-label">الاسم</label>
                                <input type="text" name="name" id="name" class="form-control"
                                    value="<?php echo e($admin->name); ?>">
                            </div>
                            <div class="form-group my-2">
                                <label for="password" class="form-label">كلمه المرور جديده</label>
                                <input type="password" name="password" id="password" class="form-control">
                            </div>
                            <div class="form-group my-2">
                                <label for="password_confirmation" class="form-label">تاكيد كلمه المرور الجديده</label>
                                <input type="password" name="password_confirmation" id="password_confirmation"
                                    class="form-control">
                            </div>
                            <div class="form-group my-2 text-center">
                                <input type="submit" value="حفظ التعديلات" class="btn btn-success">
                            </div>

                        </form>
                    </div>

                </div>
            </div>
        </div>

    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        function UpdatePreview() {
            $('#frame').attr('src', URL.createObjectURL(event.target.files[0]));
        };
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Projects\machines_project\resources\views/admin/profile/profile.blade.php ENDPATH**/ ?>