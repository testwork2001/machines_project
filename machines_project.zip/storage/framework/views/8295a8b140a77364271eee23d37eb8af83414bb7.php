
<?php $__env->startSection('title', " التعديل على {$admin->name}"); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="col-12">
            <?php echo $__env->make('admin.layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('admin.layouts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <form action="<?php echo e(route('admins.update', $admin->id)); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="col-xl-8 mb-30 mx-auto">
                <div class="card card-statistics h-100">
                    <div class="card-body">
                        <h5 class="card-title"> التعديل على بيانات المشرف <?php echo e($admin->name); ?> </h5>
                        <div>
                            <div class="mb-30">
                                <div class="card-body">
                                    <div class="form-group mb-15">
                                        <label for="name">اسم المشرف</label>
                                        <input class="form-control " type="text" placeholder="ادخل الاسم" name="name"
                                            value="<?php echo e($admin->name); ?>">
                                    </div>
                                    <div class="form-group mb-15">
                                        <label for="name">البريد الالكترونى</label>
                                        <input class="form-control " type="email" placeholder="ادخل البرد الالكترونى"
                                            name="email" value="<?php echo e($admin->email); ?>">
                                    </div>
                                    <div class="form-group mb-15">
                                        <label for="name"> كلمه مرور جديده</label>
                                        <input class="form-control" type="password" placeholder=" كلمه المرور"
                                            name="password">
                                    </div>
                                    <div class="form-group mb-15">
                                        <label for="name"> تاكيد كلمه المرور </label>
                                        <input class="form-control" type="password" placeholder="تاكيد كلمه المرور "
                                            name="password_confirmation">
                                    </div>
                                    <div class="form-group mb-15">
                                        <label for="status">الحاله</label>
                                        <select class="form-control " name="status" style="height: 50px" id="status">
                                            <option selected disabled></option>
                                            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($status); ?>"
                                                    <?php echo e($admin->status != $status ? '' : 'selected'); ?>><?php echo e($key); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group mb-15">
                                        <label for="email_verified_at">حاله البريد الالكترونى</label>
                                        <select class="form-control form-control mb-15" style="height: 50px"
                                            name="email_verified_at" id="email_verified_at">
                                            <option selected disabled></option>
                                            <option value="0" <?php echo e($admin->email_verified_at == null? 'selected' : ''); ?>>لم
                                                يتم التحقق</option>
                                            <option value="1" <?php echo e($admin->email_verified_at != null ? 'selected' : ''); ?>>تم
                                                التحقق</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <h3 class="pt-5 text-center">اختر صوره </h3>
                            <section>
                                <h4 class="sr-only">&nbsp;</h4>
                                <div class="form-group p-3 text-center ">
                                    <div class="">
                                        <label class="" for="customFile1">
                                            <img src="<?php echo e(asset($admin->getFirstMediaUrl('admins') ?? 'admin/images/admin_def.webp')); ?>" id="frame"
                                                style="width: 200px;height:200px;border-radius: 50%" />
                                            <input type="file" class="d-none" id="customFile1" name="image"
                                                oninput='UpdatePreview()'>

                                        </label>
                                    </div>
                                </div>


                            </section>
                            <div class="col-12 text-center p-3">
                                <input type="submit" value="حفظ التعديلات" class="btn btn-success my-1">
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        function UpdatePreview() {
            $('#frame').attr('src', URL.createObjectURL(event.target.files[0]));
        };
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Projects\machines_project\resources\views/admin/admins/edit.blade.php ENDPATH**/ ?>