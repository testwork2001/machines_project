
<?php $__env->startSection('title', "عرض تفاصيل {$product->name}"); ?>
<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-11 col-lg-10 mx-auto  mt-5 px-2">
        <div class=" text-right p-2 row justify-content-around " dir="rtl">
            <div class="col-11 col-lg-6 card mx-auto my-2">
                <h3 class="card-title px-3 pt-3 text-danger">
                    <?php echo e($product->name); ?>

                </h3>
                <div class="card-body">
                    <p style="font-size: 20px;line-height:1.6 ;padding-bottom:1px"><?php echo e($product->description); ?></p>
                    <p class="row justify-content-around" style="line-height:1.6">
                    <div class=" h6"><bdi>السعر: <?php echo e($product->price); ?> جنيه</bdi></div>
                    <div class="h6"><bdi>الكميه: <?php echo e($product->price); ?> وحده</bdi></div>
                    </p>
                    <table class="table">
                        <h5>مواصفات المنتج</h5>
                        <tr>
                            <th>الصفه</th>
                            <th>القيمه</th>
                        </tr>
                        <?php $__currentLoopData = $specs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($spec->name); ?></td>
                                <td><?php echo e($spec->pivot->value); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
            <div class="col-12 col-lg-6 text-center mx-auto my-2 row justify-content-between">
                <img src="<?php echo e(asset($product->getFirstMediaUrl('products'))); ?>" alt=""
                    style="width:80%; border-radius:10px;max-height:400px" class="my-1" id='myimage'>
                <div style="width: 18%">
                    <?php $__currentLoopData = $product->getMedia('products'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e(asset($media->getUrl())); ?>" alt="" style="width:100%; border-radius:10px ;cursor: pointer"
                            class="my-1 convert">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            </div>
        </div>
    </div>
    <div class="col-11 col-lg-8 mx-auto py-2 justify-content-center" dir="rtl">
        <div class='text-center'>
            <button id="switech" type="button" class="btn btn-primary"> <bdi>استفسار عن <?php echo e($product->name); ?>

                </bdi></button>
        </div>
        <div class="col-12 py-3 px-1 d-none bg-light my-2" id="form-box">
            <form action="<?php echo e(route('inquiry.store')); ?>" method="post" id="target">
                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group col-lg-8 mx-auto">
                    <label for="username" class="col-12 text-right">اسمك *</label>
                    <input type="text" name="name" id="username" required placeholder="من فضلك اكتب اسمك *"
                        class="form-control " value="<?php echo e(old('name')); ?>">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-lg-8 mx-auto">
                    <label for="email" class="col-12 text-right">البريد الالكترونى *</label>
                    <input type="email" name="email" id="email" required
                        placeholder="من فضلك اكتب البريد الالكترونى *" class="form-control " value="<?php echo e(old('email')); ?>">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-lg-8 mx-auto">
                    <label for="phone" class="col-12 text-right">الهاتف المحمول *</label>
                    <input type="tel" name="phone" id="phone" required placeholder="من فضلك اكتب الهاتف المحمول *"
                        class="form-control " value="<?php echo e(old('phone')); ?>">
                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-lg-8 mx-auto">
                    <label for="description" class="col-12 text-right">اكتب استفسارك *</label>
                    <textarea name="description" id="description" cols="30" rows="10" class="form-control"></textarea>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group text-center">
                    <input type="submit" value="ارسال الاستفسار" class="btn btn-success m-1">
                </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $('#switech').on('click', function() {
            $('#form-box').removeClass('d-none')
            $(this).removeClass('btn-primary')
            $(this).addClass('btn-danger')
        })
    </script>
    <script>
        $('.convert').on('click' , function(){
            document.getElementById('myimage').setAttribute('src' , this.src)
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Projects\machines_project\resources\views/web/details.blade.php ENDPATH**/ ?>