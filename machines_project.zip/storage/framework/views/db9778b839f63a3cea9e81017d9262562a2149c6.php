
<?php $__env->startSection('title', " عرض بيانات العميل {$client->name}"); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="col-12">
            <?php echo $__env->make('admin.layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('admin.layouts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <form action="<?php echo e(route('clients.update', $client->id)); ?>" method="post">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="col-xl-8 mb-30 mx-auto">
                <div class="card card-statistics h-100">
                    <div class="card-body">
                        <h3 class="card-title">  عرض بيانات العميل <?php echo e($client->name); ?></h3>
                        <div class="col-12 p-4 border-bottom">
                            <h5> اسم العميل : <span class="text-success"> <?php echo e($client->name); ?></span> </h5>
                        </div>
                        <div class="col-12 p-4 border-bottom">
                            <h5> البريد الالكترونى : <span class="text-success"> <?php echo e($client->email); ?></span> </h5>
                        </div>
                        <div class="col-12 p-4 border-bottom">
                            <h5> الهاتف المحمول : <span class="text-success"> <?php echo e($client->phone); ?></span> </h5>
                        </div>
                        <div class="col-12 p-4 border-bottom">
                            <h5> الحاله </h5>
                            <select name="status" class="form-control" style="height:55px;font-size:18px">
                                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($status); ?>" <?php echo e($status == $client->status ? 'selected' : ''); ?>>
                                        <?php echo e($key); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-12 p-4 border-bottom">
                            <h5> تاريخ الانشاء : <span class="text-success"> <?php echo e($client->created_at); ?></span> </h5>
                        </div>
                        <div class="col-12 p-4 border-bottom">
                            <h5> تاريخ التعديل : <span class="text-success"> <?php echo e($client->updated_at); ?></span> </h5>
                        </div>
                        <div class="col-12 text-center p-3">
                            <input type="submit" value="حفظ التعديلات" class="btn btn-success my-1">
                        </div>
                    </div>
                </div>
            </div>
        </form>

        <div class="col-xl-8 mb-30 mx-auto">
            <div class="card card-statistics h-100">
                <div class="card-body">
                    <h3 class="card-title"> الاستفسارات التى كتبها <?php echo e($client->name); ?></h3>
                    <?php $__empty_1 = true; $__currentLoopData = $client->inquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-12 p-4 border-bottom">
                        <h4> الاستفسار</span> </h4>
                        <p><?php echo e($inquiry->description); ?></p>
                        <h4>اسم المنتج</h4>
                        <p><?php echo e($inquiry->product->name); ?></p>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12 text-center p-1 text-danger fs-2">
                            لا يوجد استفسارات لهذا العميل قد تم حذفها ماخرا
                        </div>
                    <?php endif; ?> 
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Projects\machines_project\resources\views/admin/clients/edit.blade.php ENDPATH**/ ?>