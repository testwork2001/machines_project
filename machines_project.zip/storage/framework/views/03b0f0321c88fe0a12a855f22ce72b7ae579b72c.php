
<?php $__env->startSection('title', 'كل المساعدات المطلوبه'); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <?php echo $__env->make('admin.layouts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="page-title">
            <div class="row">
                <div class="col-12">
                    <h4 class="mb-2">كل المساعدات الموجوده حاليا</h4>
                </div>

            </div>
        </div>
        <div class="row">
            <div class="col-xl-12 mb-30">
                <div class="card card-statistics h-100">
                    <div class="card-body">
                        <div>
                            <table class="table  mb-0 p-0">
                                <thead>
                                    <tr>
                                        <th>رقم المساعده</th>
                                        <th> المساعده</th>
                                        <th>العميل</th>
                                        <th> البريد الالكترونى</th>
                                        <th> الهاتف المحمول</th>
                                        <th>تاريخ الانشاء</th>
                                        <th>تاريخ التعديل</th>
                                        <th>العمليات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $helps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $help): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td style="overflow: auto "> <?php echo e($help->message); ?> </td>
                                            <td> <?php echo e($help->name); ?></td>
                                            <td><?php echo e($help->email); ?></td>
                                            <td> <?php echo e($help->phone); ?></td>
                                            <td> <?php echo e($help->created_at); ?></td>
                                            <td> <?php echo e($help->updated_at); ?></td>
                                            <td>
                                                <form action="<?php echo e(route('help.destory', $help->id)); ?>" method="post"
                                                    class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <input type="submit" value="حذف" class="btn btn-outline-danger m-1">
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="8" class="text-center">لا يوجد مساعدات حاليا</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Projects\machines_project\resources\views/admin/help/index.blade.php ENDPATH**/ ?>