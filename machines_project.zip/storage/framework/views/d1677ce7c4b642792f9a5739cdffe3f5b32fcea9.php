
<?php $__env->startSection('title', 'كل الاستفسارات'); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <?php echo $__env->make('admin.layouts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="page-title">
            <div class="row">
                <div class="col-12">
                    <h4 class="mb-2">كل الاستفسارات الموجوده حاليا</h4>
                </div>

            </div>
        </div>
        <div class="row">
            <div class="col-xl-12 mb-30">
                <div class="card card-statistics h-100">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="datatable" class="table center-aligned-table mb-0 p-0">
                                <thead>
                                    <tr>
                                        <th>رقم الاستفسار</th>
                                        <th> الاستفسار</th>
                                        <th>اسم المنتج </th>
                                        <th>العميل</th>
                                        <th> البريد الالكترونى</th>
                                        <th> الهاتف المحمول</th>
                                        <th>تاريخ الانشاء</th>
                                        <th>تاريخ التعديل</th>
                                        <th>العمليات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $inquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td style="overflow: auto"> <?php echo e($inquiry->description); ?> </td>
                                            <td> <?php echo e($inquiry->product->name); ?></td>
                                            <td><?php echo e($inquiry->client->name); ?></td>
                                            <td> <?php echo e($inquiry->client->email); ?></td>
                                            <td> <?php echo e($inquiry->client->phone); ?></td>
                                            <td> <?php echo e($inquiry->created_at); ?></td>
                                            <td> <?php echo e($inquiry->client->updated_at); ?></td>
                                            <td>
                                                <form action="<?php echo e(route('inquiries.destroy', $inquiry->id)); ?>" method="post"
                                                    class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <input type="submit" value="حذف" class="btn btn-outline-danger m-1">
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Projects\machines_project\resources\views/admin/inquiries/index.blade.php ENDPATH**/ ?>